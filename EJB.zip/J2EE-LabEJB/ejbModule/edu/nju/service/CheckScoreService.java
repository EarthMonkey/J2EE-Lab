package edu.nju.service;

import java.io.IOException;
import java.util.ArrayList;

import javax.ejb.Remote;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.nju.models.ScoresPO;

@Remote
public interface CheckScoreService {

	public ArrayList<ScoresPO> checkScore(int id);

	public void forwardPage(String page, HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException;
}
