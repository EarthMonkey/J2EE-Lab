package edu.nju.service;

import java.io.IOException;
import java.util.ArrayList;

import javax.ejb.Stateless;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.nju.dao.ScoreDao;
import edu.nju.factory.EJBFactory;
import edu.nju.models.ScoresPO;

@Stateless(name="CheckScoreService")
public class CheckScoreServiceImpl implements CheckScoreService {

	private static CheckScoreService scoreService = new CheckScoreServiceImpl();

	public static CheckScoreService getInstance() {
		return scoreService;
	}
	
	
	@Override
	public ArrayList<ScoresPO> checkScore(int id) {
		 ScoreDao scoreDao = (ScoreDao)EJBFactory.getEJB("ejb:/J2EE-LabEJB/ScoreDaoEJB!edu.nju.dao.ScoreDao");
		 return scoreDao.find(id);
	}

	@Override
	public void forwardPage(String page, HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher dispatcher = req.getRequestDispatcher(resp.encodeURL(page));
		dispatcher.forward(req, resp);
	}

}
