package edu.nju.dao;

import java.util.ArrayList;

import javax.ejb.Remote;

import edu.nju.models.ScoresPO;

@Remote
public interface ScoreDao {
	
	public void createData();

	public ArrayList<ScoresPO> find(int id);
	
}
